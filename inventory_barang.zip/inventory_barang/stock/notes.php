<?php
session_start();
include_once '../dbconnect.php';

// Pastikan session 'id' dan 'user' sudah di-set
if (!isset($_SESSION['id']) || !isset($_SESSION['user'])) {
    header('Location: login.php'); // Sesuaikan dengan halaman login
    exit();
}

$konten = mysqli_real_escape_string($conn, $_POST['konten']);
$oleh = $_SESSION['user'];

$update = "INSERT INTO notes (contents, admin) VALUES ('$konten', '$oleh')";
$hasil = mysqli_query($conn, $update);

if ($hasil) {
    echo "<div class='alert alert-success'>
        <strong>Success!</strong> Redirecting you back in 1 second.
      </div>";
    header('Refresh: 1; URL=index.php');
    exit();
} else {
    echo "<div class='alert alert-warning'>
        <strong>Failed!</strong> Redirecting you back in 1 second.
      </div>";
    header('Refresh: 1; URL=index.php');
    exit();
}
?>
